import { ArrowLeft, ChevronRight, Shield } from "lucide-react";
import { Link, useParams } from "react-router";
import { BottomNav } from "../components/BottomNav";
import { useState } from "react";

const quickAmounts = ["₹5K", "₹10K", "₹25K", "₹50K"];

export default function InvestScreen() {
  const { id } = useParams();
  const [amount, setAmount] = useState(10000);
  const [selectedPayment, setSelectedPayment] = useState("upi");

  const isStableIncome = id === "stable-income";
  const expectedYield = isStableIncome ? 8.2 : 9.6;
  const yearlyReturn = Math.round((amount * expectedYield) / 100);
  const monthlyPayout = Math.round(yearlyReturn / 12);

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white pb-20">
      {/* Header */}
      <div className="bg-[#0f1420] px-4 py-4 border-b border-gray-800">
        <div className="flex justify-between items-center mb-4">
          <div className="text-[11px] text-gray-400">9:41</div>
          <div className="flex gap-1">
            <div className="text-[11px]">📶</div>
            <div className="text-[11px]">📡</div>
            <div className="text-[11px]">🔋</div>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <Link to={`/portfolio/${id}`} className="p-2 -ml-2">
            <ArrowLeft className="size-5" />
          </Link>
          <div>
            <div className="text-lg">Invest in</div>
            <div className="text-sm text-gray-400">
              {isStableIncome ? "Stable Income Basket" : "High Yield Opportunities"}
            </div>
          </div>
        </div>
      </div>

      {/* Description */}
      <div className="px-4 py-4">
        <p className="text-sm text-gray-400">
          You're one step away from stable returns
        </p>
      </div>

      {/* Amount Input */}
      <div className="px-4 mb-6">
        <div className="bg-[#0f1420] rounded-2xl p-6 border border-gray-800">
          <div className="text-center mb-4">
            <div className="text-4xl mb-2">₹{amount.toLocaleString('en-IN')}</div>
            <div className="text-xs text-gray-400">Minimum ₹5,000</div>
          </div>

          {/* Slider */}
          <div className="mb-4">
            <input
              type="range"
              min="5000"
              max="100000"
              step="1000"
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
              style={{
                background: `linear-gradient(to right, #4ade80 0%, #4ade80 ${((amount - 5000) / (100000 - 5000)) * 100}%, #374151 ${((amount - 5000) / (100000 - 5000)) * 100}%, #374151 100%)`
              }}
            />
          </div>

          {/* Quick Select */}
          <div className="flex gap-2">
            {quickAmounts.map((amt) => (
              <button
                key={amt}
                onClick={() => {
                  const value = parseInt(amt.replace('₹', '').replace('K', '000'));
                  setAmount(value);
                }}
                className="flex-1 py-2 bg-[#1a2332] rounded-lg text-sm hover:bg-[#242f42] transition-colors"
              >
                {amt}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Returns Preview */}
      <div className="px-4 mb-6">
        <h3 className="text-base mb-3">Returns Preview</h3>
        <div className="bg-[#0f1420] rounded-2xl p-4 border border-gray-800">
          <div className="text-xs text-gray-400 text-center mb-2">
            At {expectedYield}% p.a. expected yield
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-2xl text-[#4ade80] mb-1">₹{yearlyReturn.toLocaleString('en-IN')}</div>
              <div className="text-xs text-gray-400">Est. Yearly Return</div>
            </div>
            <div className="text-center">
              <div className="text-2xl text-[#4ade80] mb-1">₹{monthlyPayout}</div>
              <div className="text-xs text-gray-400">Est. Monthly Payout</div>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Method */}
      <div className="px-4 mb-6">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-base">Payment Method</h3>
          <span className="text-xs text-[#4ade80] bg-[#4ade80]/10 px-2 py-1 rounded">
            Recommended
          </span>
        </div>
        <div className="space-y-2">
          <button
            onClick={() => setSelectedPayment("upi")}
            className={`w-full bg-[#0f1420] rounded-xl p-4 border flex items-center justify-between transition-colors ${
              selectedPayment === "upi" ? "border-[#4ade80]" : "border-gray-800"
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center text-xl">
                📱
              </div>
              <div className="text-left">
                <div className="text-sm">UPI</div>
                <div className="text-xs text-gray-400">Pay using any UPI app</div>
              </div>
            </div>
            {selectedPayment === "upi" && (
              <div className="w-6 h-6 bg-[#4ade80] rounded-full flex items-center justify-center">
                <div className="text-black text-xs">✓</div>
              </div>
            )}
          </button>

          <button
            onClick={() => setSelectedPayment("netbanking")}
            className={`w-full bg-[#0f1420] rounded-xl p-4 border flex items-center justify-between transition-colors ${
              selectedPayment === "netbanking" ? "border-[#4ade80]" : "border-gray-800"
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center text-xl">
                🏦
              </div>
              <div className="text-left">
                <div className="text-sm">Net Banking</div>
                <div className="text-xs text-gray-400">All major banks supported</div>
              </div>
            </div>
            {selectedPayment === "netbanking" && (
              <div className="w-6 h-6 bg-[#4ade80] rounded-full flex items-center justify-center">
                <div className="text-black text-xs">✓</div>
              </div>
            )}
          </button>
        </div>
      </div>

      {/* Security Badge */}
      <div className="px-4 mb-6">
        <div className="flex items-center gap-2 justify-center text-sm text-gray-400">
          <Shield className="size-4" />
          <span>100% Secure Transactions</span>
        </div>
      </div>

      {/* CTA Button */}
      <div className="px-4 mb-6">
        <button className="w-full bg-[#4ade80] text-black py-4 rounded-xl flex items-center justify-center gap-2 hover:bg-[#3dcc70] transition-colors group">
          <span>Swipe to Invest</span>
          <ChevronRight className="size-5 group-hover:translate-x-1 transition-transform" />
        </button>
        <p className="text-xs text-center text-gray-500 mt-3">
          By investing, you agree to our <span className="text-[#4ade80]">T&C</span>
        </p>
      </div>

      <BottomNav />
    </div>
  );
}
