import { ArrowLeft } from "lucide-react";
import { Link } from "react-router";
import { BottomNav } from "../components/BottomNav";

const comparisonData = [
  {
    feature: "Returns",
    ourDebt: "8.0% - 10.0% p.a.",
    fd: "5.5% - 7.0% p.a."
  },
  {
    feature: "Liquidity",
    ourDebt: "Medium (Easy Exit)",
    fd: "Low (Lock-in)"
  },
  {
    feature: "Transparency",
    ourDebt: "High (Know what you own)",
    fd: "Low (No visibility)"
  },
  {
    feature: "Diversification",
    ourDebt: "High (Multiple bonds)",
    fd: "None (Single instrument)"
  },
  {
    feature: "Min. Investment",
    ourDebt: "₹5,000",
    fd: "₹25,000+"
  },
  {
    feature: "Tax Efficiency",
    ourDebt: "Better (Indexation benefit)",
    fd: "Lower (Fully taxable)"
  }
];

export default function WhyDebtMarket() {
  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white pb-20">
      {/* Header */}
      <div className="bg-[#0f1420] px-4 py-4 border-b border-gray-800">
        <div className="flex justify-between items-center mb-4">
          <div className="text-[11px] text-gray-400">9:41</div>
          <div className="flex gap-1">
            <div className="text-[11px]">📶</div>
            <div className="text-[11px]">📡</div>
            <div className="text-[11px]">🔋</div>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <Link to="/account" className="p-2 -ml-2">
            <ArrowLeft className="size-5" />
          </Link>
          <h1 className="text-xl">Why Choose Us?</h1>
        </div>
      </div>

      {/* Header Section */}
      <div className="px-4 py-6">
        <h2 className="text-2xl mb-3">Compared to Fixed Deposits (FD)</h2>
      </div>

      {/* Comparison Table */}
      <div className="px-4 mb-6">
        <div className="bg-[#0f1420] rounded-2xl overflow-hidden border border-gray-800">
          {/* Table Header */}
          <div className="grid grid-cols-3 gap-4 p-4 border-b border-gray-800 bg-[#1a2332]">
            <div className="text-xs text-gray-400">Feature</div>
            <div className="text-xs text-[#4ade80] text-center">Our Debt Portfolios</div>
            <div className="text-xs text-gray-400 text-center">FD (Fixed Deposit)</div>
          </div>

          {/* Table Body */}
          {comparisonData.map((row, idx) => (
            <div
              key={idx}
              className={`grid grid-cols-3 gap-4 p-4 ${
                idx !== comparisonData.length - 1 ? 'border-b border-gray-800' : ''
              }`}
            >
              <div className="text-sm">{row.feature}</div>
              <div className="text-sm text-[#4ade80] text-center font-medium">
                {row.ourDebt}
              </div>
              <div className="text-sm text-gray-400 text-center">
                {row.fd}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Key Benefits */}
      <div className="px-4 mb-6">
        <h3 className="text-lg mb-4">Key Benefits</h3>
        <div className="space-y-3">
          <div className="bg-[#0f1420] rounded-xl p-4 border border-gray-800">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-[#4ade80]/20 rounded-lg flex items-center justify-center text-xl shrink-0">
                📈
              </div>
              <div>
                <h4 className="text-sm mb-1">Higher Returns</h4>
                <p className="text-xs text-gray-400">
                  Earn 8-10% p.a. compared to 5.5-7% in FDs, significantly better than traditional options
                </p>
              </div>
            </div>
          </div>

          <div className="bg-[#0f1420] rounded-xl p-4 border border-gray-800">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center text-xl shrink-0">
                💎
              </div>
              <div>
                <h4 className="text-sm mb-1">Full Transparency</h4>
                <p className="text-xs text-gray-400">
                  See exactly which bonds you own and their individual performance at all times
                </p>
              </div>
            </div>
          </div>

          <div className="bg-[#0f1420] rounded-xl p-4 border border-gray-800">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center text-xl shrink-0">
                🎯
              </div>
              <div>
                <h4 className="text-sm mb-1">Better Liquidity</h4>
                <p className="text-xs text-gray-400">
                  Exit anytime without penalties, unlike FDs with lock-in periods and premature withdrawal charges
                </p>
              </div>
            </div>
          </div>

          <div className="bg-[#0f1420] rounded-xl p-4 border border-gray-800">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-orange-500/20 rounded-lg flex items-center justify-center text-xl shrink-0">
                🏆
              </div>
              <div>
                <h4 className="text-sm mb-1">Professional Diversification</h4>
                <p className="text-xs text-gray-400">
                  Spread risk across multiple high-quality bonds instead of putting all money in one place
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Promise Section */}
      <div className="px-4 mb-6">
        <div className="bg-gradient-to-br from-[#4ade80]/20 to-[#22c55e]/20 rounded-2xl p-5 border border-[#4ade80]/30">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-12 h-12 bg-[#4ade80]/20 rounded-lg flex items-center justify-center text-2xl shrink-0">
              🛡️
            </div>
            <div className="flex-1">
              <h3 className="text-base mb-2">Our Promise</h3>
              <p className="text-sm text-gray-300">
                We help you build wealth with safe, transparent and high-yield bond investments.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Button */}
      <div className="px-4 mb-6">
        <Link
          to="/"
          className="block w-full bg-[#4ade80] text-black py-4 rounded-xl text-center hover:bg-[#3dcc70] transition-colors"
        >
          Start Investing Today
          <div className="text-xs opacity-80">Min. ₹5,000</div>
        </Link>
      </div>

      <BottomNav />
    </div>
  );
}
