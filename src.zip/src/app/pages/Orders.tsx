import { BottomNav } from "../components/BottomNav";
import { CheckCircle, Clock, XCircle } from "lucide-react";

const orders = [
  {
    id: 1,
    portfolio: "Stable Income Basket",
    amount: "₹10,000",
    date: "Apr 5, 2026",
    status: "completed",
    type: "Buy"
  },
  {
    id: 2,
    portfolio: "High Yield Opportunities",
    amount: "₹15,000",
    date: "Apr 3, 2026",
    status: "completed",
    type: "Buy"
  },
  {
    id: 3,
    portfolio: "Safe Income",
    amount: "₹5,000",
    date: "Apr 1, 2026",
    status: "pending",
    type: "Buy"
  },
  {
    id: 4,
    portfolio: "Stable Income Basket",
    amount: "₹2,500",
    date: "Mar 28, 2026",
    status: "cancelled",
    type: "Sell"
  }
];

export default function Orders() {
  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white pb-20">
      {/* Header */}
      <div className="bg-[#0f1420] px-4 py-4 border-b border-gray-800">
        <div className="flex justify-between items-center mb-4">
          <div className="text-[11px] text-gray-400">9:41</div>
          <div className="flex gap-1">
            <div className="text-[11px]">📶</div>
            <div className="text-[11px]">📡</div>
            <div className="text-[11px]">🔋</div>
          </div>
        </div>
        
        <h1 className="text-xl">Orders</h1>
        <p className="text-sm text-gray-400 mt-1">Your transaction history</p>
      </div>

      {/* Filters */}
      <div className="px-4 py-4">
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          <button className="px-4 py-2 bg-[#4ade80] text-black rounded-lg text-sm whitespace-nowrap">
            All
          </button>
          <button className="px-4 py-2 bg-[#0f1420] text-gray-400 border border-gray-800 rounded-lg text-sm whitespace-nowrap">
            Completed
          </button>
          <button className="px-4 py-2 bg-[#0f1420] text-gray-400 border border-gray-800 rounded-lg text-sm whitespace-nowrap">
            Pending
          </button>
          <button className="px-4 py-2 bg-[#0f1420] text-gray-400 border border-gray-800 rounded-lg text-sm whitespace-nowrap">
            Cancelled
          </button>
        </div>
      </div>

      {/* Orders List */}
      <div className="px-4 pb-6">
        <div className="space-y-3">
          {orders.map((order) => (
            <div
              key={order.id}
              className="bg-[#0f1420] rounded-xl p-4 border border-gray-800"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-sm">{order.portfolio}</h3>
                  </div>
                  <p className="text-xs text-gray-400">{order.date}</p>
                </div>
                <div className="flex items-center gap-2">
                  {order.status === "completed" && (
                    <div className="flex items-center gap-1 text-xs text-[#4ade80]">
                      <CheckCircle className="size-4" />
                      <span>Completed</span>
                    </div>
                  )}
                  {order.status === "pending" && (
                    <div className="flex items-center gap-1 text-xs text-yellow-500">
                      <Clock className="size-4" />
                      <span>Pending</span>
                    </div>
                  )}
                  {order.status === "cancelled" && (
                    <div className="flex items-center gap-1 text-xs text-red-500">
                      <XCircle className="size-4" />
                      <span>Cancelled</span>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-3 border-t border-gray-800">
                <div>
                  <span className={`px-2 py-1 rounded text-xs ${
                    order.type === "Buy" 
                      ? "bg-[#4ade80]/20 text-[#4ade80]" 
                      : "bg-red-500/20 text-red-400"
                  }`}>
                    {order.type}
                  </span>
                </div>
                <div className="text-base">{order.amount}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
