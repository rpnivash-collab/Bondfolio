import { ArrowLeft, Bookmark, Share2 } from "lucide-react";
import { Link, useParams } from "react-router";
import { BottomNav } from "../components/BottomNav";
import { LineChart, Line, XAxis, ResponsiveContainer } from "recharts";

const performanceData = [
  { year: "1Y", value: 5 },
  { year: "2Y", value: 7 },
  { year: "3Y", value: 6.5 },
  { year: "4Y", value: 8 },
  { year: "5Y", value: 8.2 },
];

const holdings = [
  { name: "G-Sec 2028", type: "Government Bond", percentage: "40%", yield: "7.1%", color: "#3b82f6", icon: "🔵" },
  { name: "REC Limited Bond", type: "PSU Bond", percentage: "30%", yield: "8.5%", color: "#f97316", icon: "🟠" },
  { name: "HDFC Bank Bond", type: "Corporate Bond", percentage: "30%", yield: "8.2%", color: "#06b6d4", icon: "🔷" },
];

export default function PortfolioDetails() {
  const { id } = useParams();
  const isStableIncome = id === "stable-income";

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white pb-20">
      {/* Header */}
      <div className="bg-[#0f1420] px-4 py-4 border-b border-gray-800">
        <div className="flex justify-between items-center mb-4">
          <div className="text-[11px] text-gray-400">9:41</div>
          <div className="flex gap-1">
            <div className="text-[11px]">📶</div>
            <div className="text-[11px]">📡</div>
            <div className="text-[11px]">🔋</div>
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          <Link to="/" className="p-2 -ml-2">
            <ArrowLeft className="size-5" />
          </Link>
          <div className="flex gap-3">
            <button className="p-2">
              <Bookmark className="size-5" />
            </button>
            <button className="p-2">
              <Share2 className="size-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Portfolio Header */}
      <div className="px-4 py-6">
        <h1 className="text-2xl mb-2">
          {isStableIncome ? "Stable Income Basket" : "High Yield Opportunities"}
        </h1>
        <div className="flex items-center gap-3 mb-4">
          <span className="bg-[#4ade80] text-black px-3 py-1 rounded-full text-xs">
            {isStableIncome ? "Low Risk" : "Moderate Risk"}
          </span>
          <span className="bg-red-500/20 text-red-400 px-3 py-1 rounded-full text-xs">
            Diversified
          </span>
        </div>
        <p className="text-sm text-gray-400">
          Risk: {isStableIncome ? "Highest credit quality bonds for stable and predictable returns" : "Strategic mix of high-rated bonds for stable returns"}
        </p>
      </div>

      {/* Key Stats */}
      <div className="px-4 mb-6">
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-[#0f1420] rounded-xl p-4 border border-gray-800">
            <div className="text-2xl text-[#4ade80] mb-1">
              {isStableIncome ? "8.2%" : "9.6%"} <span className="text-base text-gray-400">p.a.</span>
            </div>
            <div className="text-xs text-gray-400">Expected Yield</div>
          </div>
          <div className="bg-[#0f1420] rounded-xl p-4 border border-gray-800">
            <div className="text-2xl text-[#4ade80] mb-1">
              {isStableIncome ? "2.5" : "3.2"} <span className="text-base text-gray-400">yrs</span>
            </div>
            <div className="text-xs text-gray-400">Avg. Duration</div>
          </div>
        </div>
      </div>

      {/* Expected Returns Over Time */}
      <div className="px-4 mb-6">
        <h3 className="text-base mb-3">Expected Returns Over Time</h3>
        <div className="bg-[#0f1420] rounded-xl p-4 border border-gray-800">
          <div className="h-40 mb-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={performanceData}>
                <XAxis 
                  dataKey="year" 
                  stroke="#6b7280"
                  tick={{ fill: '#9ca3af', fontSize: 12 }}
                  axisLine={{ stroke: '#374151' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#4ade80" 
                  strokeWidth={3}
                  dot={{ fill: '#4ade80', r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="text-xs text-center text-gray-400">
            8.2% at 2.5 yrs
          </div>
        </div>
      </div>

      {/* Allocation */}
      <div className="px-4 mb-6">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-base">Allocation</h3>
          <button className="text-sm text-[#4ade80]">View Details</button>
        </div>
        <div className="bg-[#0f1420] rounded-xl p-4 border border-gray-800">
          <div className="flex gap-2 mb-3">
            <div className="flex-[40] h-3 bg-[#3b82f6] rounded-full"></div>
            <div className="flex-[30] h-3 bg-[#f97316] rounded-full"></div>
            <div className="flex-[30] h-3 bg-[#06b6d4] rounded-full"></div>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div>
              <div className="text-sm">40%</div>
              <div className="text-xs text-gray-400">Govt Bonds</div>
            </div>
            <div>
              <div className="text-sm">30%</div>
              <div className="text-xs text-gray-400">PSU Bonds</div>
            </div>
            <div>
              <div className="text-sm">30%</div>
              <div className="text-xs text-gray-400">Bonds</div>
            </div>
          </div>
        </div>
      </div>

      {/* Top Holdings */}
      <div className="px-4 mb-6">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-base">Top Holdings</h3>
          <div className="text-xs text-gray-400">Yield (p.a.)</div>
        </div>
        <div className="space-y-2">
          {holdings.map((holding, idx) => (
            <div
              key={idx}
              className="bg-[#0f1420] rounded-xl p-4 border border-gray-800 flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#1a2332] flex items-center justify-center text-xl">
                  {holding.icon}
                </div>
                <div>
                  <div className="text-sm">{holding.name}</div>
                  <div className="text-xs text-gray-400">{holding.type}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm">{holding.yield}</div>
                <div className="text-xs text-gray-400">{holding.percentage} of portfolio</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA Button */}
      <div className="px-4 mb-6">
        <Link
          to={`/invest/${id}`}
          className="block w-full bg-[#4ade80] text-black py-4 rounded-xl text-center hover:bg-[#3dcc70] transition-colors"
        >
          Invest Now
          <div className="text-xs opacity-80">Min. ₹5,000</div>
        </Link>
      </div>

      <BottomNav />
    </div>
  );
}
