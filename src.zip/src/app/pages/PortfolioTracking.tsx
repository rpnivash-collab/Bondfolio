import { Eye, Plus } from "lucide-react";
import { BottomNav } from "../components/BottomNav";
import { LineChart, Line, XAxis, ResponsiveContainer } from "recharts";

const performanceData = [
  { month: "Jan", value: 19500 },
  { month: "Feb", value: 19800 },
  { month: "Mar", value: 20200 },
  { month: "Apr", value: 20500 },
  { month: "May", value: 21000 },
  { month: "Jun", value: 21300 },
];

const holdings = [
  { name: "G-Sec 2028", type: "Government Bond", percentage: "40%", yield: "7.1%", icon: "🔵" },
  { name: "REC Limited Bond", type: "30% of portfolio", percentage: "30%", yield: "8.5%", icon: "🟠" },
  { name: "HDFC Bank Bond", type: "30% of portfolio", percentage: "30%", yield: "8.2%", icon: "🔷" },
];

export default function PortfolioTracking() {
  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white pb-20">
      {/* Header */}
      <div className="bg-[#0f1420] px-4 py-4 border-b border-gray-800">
        <div className="flex justify-between items-center mb-4">
          <div className="text-[11px] text-gray-400">9:41</div>
          <div className="flex gap-1">
            <div className="text-[11px]">📶</div>
            <div className="text-[11px]">📡</div>
            <div className="text-[11px]">🔋</div>
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          <h1 className="text-xl">My Portfolio</h1>
          <div className="flex gap-3">
            <button className="p-2">
              <Eye className="size-5" />
            </button>
            <button className="p-2">
              <Plus className="size-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Portfolio Summary */}
      <div className="px-4 py-6">
        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="bg-[#0f1420] rounded-xl p-4 border border-gray-800">
            <div className="text-xs text-gray-400 mb-1">Invested</div>
            <div className="text-2xl">₹20,000</div>
          </div>
          <div className="bg-[#0f1420] rounded-xl p-4 border border-gray-800">
            <div className="text-xs text-gray-400 mb-1">Current Value</div>
            <div className="text-2xl text-[#4ade80]">₹21,300</div>
            <div className="text-xs text-[#4ade80] mt-1">+6.5%</div>
          </div>
        </div>
      </div>

      {/* Performance Graph */}
      <div className="px-4 mb-6">
        <div className="bg-[#0f1420] rounded-2xl p-4 border border-gray-800">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-base">Performance</h3>
            <div className="flex gap-2">
              <button className="px-3 py-1 bg-[#4ade80] text-black rounded text-xs">6M</button>
              <button className="px-3 py-1 bg-[#1a2332] text-gray-400 rounded text-xs">1Y</button>
              <button className="px-3 py-1 bg-[#1a2332] text-gray-400 rounded text-xs">3Y</button>
            </div>
          </div>

          <div className="mb-4">
            <div className="text-xs text-gray-400 mb-1">25K</div>
            <div className="text-xs text-gray-400 mb-1">20K</div>
            <div className="text-xs text-gray-400 mb-1">15K</div>
            <div className="text-xs text-gray-400 mb-1">10K</div>
            <div className="text-xs text-gray-400 mb-1">5K</div>
            <div className="text-xs text-gray-400">0</div>
          </div>

          <div className="h-40 -mx-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={performanceData}>
                <XAxis 
                  dataKey="month" 
                  stroke="#6b7280"
                  tick={{ fill: '#9ca3af', fontSize: 10 }}
                  axisLine={{ stroke: '#374151' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#4ade80" 
                  strokeWidth={3}
                  dot={false}
                  fill="url(#gradient)"
                />
                <defs>
                  <linearGradient id="gradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#4ade80" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#4ade80" stopOpacity={0} />
                  </linearGradient>
                </defs>
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Monthly Income Card */}
      <div className="px-4 mb-6">
        <div className="bg-gradient-to-br from-[#4ade80]/20 to-[#22c55e]/20 rounded-2xl p-5 border border-[#4ade80]/30">
          <div className="flex items-center justify-between mb-2">
            <div>
              <div className="text-xs text-gray-300 mb-1">Monthly Income</div>
              <div className="text-3xl">₹167</div>
            </div>
            <div className="w-12 h-12 bg-[#4ade80]/20 rounded-full flex items-center justify-center text-2xl">
              💰
            </div>
          </div>
          <div className="text-xs text-gray-400">
            Next Payout: <span className="text-[#4ade80]">Apr 12, 2024</span>
          </div>
        </div>
      </div>

      {/* Holdings */}
      <div className="px-4 mb-6">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-base">Holdings</h3>
          <button className="text-sm text-[#4ade80]">View All</button>
        </div>
        <div className="space-y-2">
          {holdings.map((holding, idx) => (
            <div
              key={idx}
              className="bg-[#0f1420] rounded-xl p-4 border border-gray-800 flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#1a2332] flex items-center justify-center text-xl">
                  {holding.icon}
                </div>
                <div>
                  <div className="text-sm">{holding.name}</div>
                  <div className="text-xs text-gray-400">{holding.type}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm">{holding.yield}</div>
                <div className="text-xs text-gray-400">{holding.percentage}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
