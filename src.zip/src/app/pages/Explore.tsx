import { Link } from "react-router";
import { BottomNav } from "../components/BottomNav";
import { TrendingUp, Shield, DollarSign } from "lucide-react";

const portfolioTypes = [
  {
    id: "safe-income",
    name: "Safe Income",
    returns: "6-7%",
    risk: "Lowest",
    description: "Highest credit quality bonds (AAA/A1+)",
    icon: Shield,
    color: "from-blue-500/20 to-blue-600/20",
    borderColor: "border-blue-500/30"
  },
  {
    id: "stable-income",
    name: "Balanced Yield",
    returns: "7-8%",
    risk: "Low",
    description: "Mix of AAA and AA rated bonds",
    icon: TrendingUp,
    color: "from-[#4ade80]/20 to-[#22c55e]/20",
    borderColor: "border-[#4ade80]/30"
  },
  {
    id: "high-yield",
    name: "High Yield",
    returns: "8-10%",
    risk: "Moderate",
    description: "Includes AA and A rated bonds",
    icon: DollarSign,
    color: "from-orange-500/20 to-orange-600/20",
    borderColor: "border-orange-500/30"
  }
];

export default function Explore() {
  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white pb-20">
      {/* Header */}
      <div className="bg-[#0f1420] px-4 py-4 border-b border-gray-800">
        <div className="flex justify-between items-center mb-4">
          <div className="text-[11px] text-gray-400">9:41</div>
          <div className="flex gap-1">
            <div className="text-[11px]">📶</div>
            <div className="text-[11px]">📡</div>
            <div className="text-[11px]">🔋</div>
          </div>
        </div>
        
        <h1 className="text-xl">Explore Portfolios</h1>
        <p className="text-sm text-gray-400 mt-1">Choose your risk profile</p>
      </div>

      {/* Portfolio Types */}
      <div className="px-4 py-6 space-y-4">
        {portfolioTypes.map((portfolio) => {
          const Icon = portfolio.icon;
          return (
            <div
              key={portfolio.id}
              className={`bg-gradient-to-br ${portfolio.color} rounded-2xl p-5 border ${portfolio.borderColor}`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg mb-1">{portfolio.name}</h3>
                  <p className="text-sm text-gray-300 mb-3">{portfolio.description}</p>
                  <div className="flex items-center gap-4 text-sm">
                    <div>
                      <span className="text-gray-400">Returns: </span>
                      <span className="text-[#4ade80]">{portfolio.returns}</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Risk: </span>
                      <span>{portfolio.risk}</span>
                    </div>
                  </div>
                </div>
                <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center">
                  <Icon className="size-6 text-[#4ade80]" />
                </div>
              </div>
              <Link
                to={`/portfolio/${portfolio.id}`}
                className="block w-full bg-[#4ade80] text-black py-3 rounded-lg text-center hover:bg-[#3dcc70] transition-colors"
              >
                View Details
              </Link>
            </div>
          );
        })}
      </div>

      <BottomNav />
    </div>
  );
}
