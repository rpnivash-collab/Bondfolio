import { Settings, ChevronRight } from "lucide-react";
import { Link } from "react-router";
import { BottomNav } from "../components/BottomNav";

const menuItems = [
  { icon: "💳", label: "Transactions", description: "" },
  { icon: "📊", label: "Tax Reports", description: "FY 2025-26" },
  { icon: "🏦", label: "Bank Accounts", description: "2 Linked" },
  { icon: "📄", label: "Documents", description: "KYC, Reports" },
  { icon: "⚙️", label: "Settings", description: "Security, Preferences" },
];

export default function Account() {
  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white pb-20">
      {/* Header */}
      <div className="bg-[#0f1420] px-4 py-4 border-b border-gray-800">
        <div className="flex justify-between items-center mb-4">
          <div className="text-[11px] text-gray-400">9:41</div>
          <div className="flex gap-1">
            <div className="text-[11px]">📶</div>
            <div className="text-[11px]">📡</div>
            <div className="text-[11px]">🔋</div>
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          <h1 className="text-xl">Account</h1>
          <button className="p-2">
            <Settings className="size-5" />
          </button>
        </div>
      </div>

      {/* Profile Section */}
      <div className="px-4 py-6">
        <div className="bg-[#0f1420] rounded-2xl p-5 border border-gray-800">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-2xl">
              👤
            </div>
            <div className="flex-1">
              <div className="text-lg mb-1">Manasa K</div>
              <div className="text-sm text-gray-400">manasa.k@email.com</div>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <div className="bg-[#4ade80]/20 text-[#4ade80] px-3 py-1 rounded-full">
              KYC Verified
            </div>
          </div>
        </div>
      </div>

      {/* Account Summary */}
      <div className="px-4 mb-6">
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-[#0f1420] rounded-xl p-4 border border-gray-800 text-center">
            <div className="text-2xl mb-1">₹30,000</div>
            <div className="text-xs text-gray-400">Total Invested</div>
          </div>
          <div className="bg-[#0f1420] rounded-xl p-4 border border-gray-800 text-center">
            <div className="text-2xl mb-1">3</div>
            <div className="text-xs text-gray-400">Portfolios</div>
          </div>
          <div className="bg-[#0f1420] rounded-xl p-4 border border-gray-800 text-center">
            <div className="text-2xl text-[#4ade80] mb-1">₹1,300</div>
            <div className="text-xs text-gray-400">Total Returns</div>
            <div className="text-xs text-[#4ade80]">+6.2%</div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-4 mb-6">
        <div className="grid grid-cols-4 gap-3">
          <button className="flex flex-col items-center gap-2 p-3 bg-[#0f1420] rounded-xl border border-gray-800">
            <div className="w-12 h-12 bg-[#4ade80]/20 rounded-full flex items-center justify-center text-xl">
              ➕
            </div>
            <div className="text-xs text-gray-400">Add Money</div>
          </button>
          <button className="flex flex-col items-center gap-2 p-3 bg-[#0f1420] rounded-xl border border-gray-800">
            <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center text-xl">
              💸
            </div>
            <div className="text-xs text-gray-400">Withdraw</div>
          </button>
          <button className="flex flex-col items-center gap-2 p-3 bg-[#0f1420] rounded-xl border border-gray-800">
            <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center text-xl">
              🎁
            </div>
            <div className="text-xs text-gray-400">Invite & Earn</div>
          </button>
          <button className="flex flex-col items-center gap-2 p-3 bg-[#0f1420] rounded-xl border border-gray-800">
            <div className="w-12 h-12 bg-orange-500/20 rounded-full flex items-center justify-center text-xl">
              ❓
            </div>
            <div className="text-xs text-gray-400">Help</div>
          </button>
        </div>
      </div>

      {/* Menu Items */}
      <div className="px-4 mb-6">
        <div className="space-y-2">
          {menuItems.map((item, idx) => (
            <button
              key={idx}
              className="w-full bg-[#0f1420] rounded-xl p-4 border border-gray-800 flex items-center justify-between hover:border-gray-700 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#1a2332] rounded-lg flex items-center justify-center text-xl">
                  {item.icon}
                </div>
                <div className="text-left">
                  <div className="text-sm">{item.label}</div>
                  {item.description && (
                    <div className="text-xs text-gray-400">{item.description}</div>
                  )}
                </div>
              </div>
              <ChevronRight className="size-5 text-gray-500" />
            </button>
          ))}
        </div>
      </div>

      {/* Promise Section */}
      <div className="px-4 mb-6">
        <div className="bg-gradient-to-br from-[#4ade80]/20 to-[#22c55e]/20 rounded-2xl p-5 border border-[#4ade80]/30">
          <div className="flex items-start gap-3 mb-3">
            <div className="w-12 h-12 bg-[#4ade80]/20 rounded-lg flex items-center justify-center text-2xl">
              🛡️
            </div>
            <div className="flex-1">
              <h3 className="text-base mb-2">Our Promise</h3>
              <p className="text-sm text-gray-300">
                We help you build wealth with safe, transparent and high-yield bond investments.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Button */}
      <div className="px-4 mb-6">
        <Link
          to="/why-debt"
          className="block w-full bg-[#4ade80] text-black py-4 rounded-xl text-center hover:bg-[#3dcc70] transition-colors"
        >
          Start Investing Today
          <div className="text-xs opacity-80">Min. ₹5,000</div>
        </Link>
      </div>

      <BottomNav />
    </div>
  );
}
