import { Bell, Search, TrendingUp } from "lucide-react";
import { Link } from "react-router";
import { BottomNav } from "../components/BottomNav";
import { LineChart, Line, ResponsiveContainer } from "recharts";

const portfolioData = [
  { name: "Stable Income Basket", returns: "8.2%", risk: "Low Risk", duration: "2.5 yrs", minInvest: "₹5,000", id: "stable-income" },
  { name: "High Yield Opportunities", returns: "9.6%", risk: "Moderate Risk", duration: "3.2 yrs", minInvest: "₹5,000", id: "high-yield" },
];

const sparklineData = [
  { value: 20 }, { value: 25 }, { value: 22 }, { value: 30 }, { value: 28 }, { value: 35 }, { value: 40 }
];

const categories = ["All", "Low Risk", "Monthly Income", "Tax Saving"];

export default function Home() {
  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white pb-20">
      {/* Header */}
      <div className="bg-[#0f1420] px-4 py-4 border-b border-gray-800">
        <div className="flex justify-between items-center mb-4">
          <div className="text-[11px] text-gray-400">9:41</div>
          <div className="flex gap-1">
            <div className="text-[11px]">📶</div>
            <div className="text-[11px]">📡</div>
            <div className="text-[11px]">🔋</div>
          </div>
        </div>
        
        <div className="flex justify-between items-start">
          <div>
            <div className="text-xs text-gray-400">Good Evening,</div>
            <div className="text-lg">Manasa 👋</div>
            <div className="text-xs text-gray-400 mt-1">Here's your portfolio overview</div>
          </div>
          <button className="p-2">
            <Bell className="size-5" />
          </button>
        </div>
      </div>

      {/* Net Worth Card */}
      <div className="px-4 py-4">
        <div className="bg-[#0f1420] rounded-2xl p-4 border border-gray-800">
          <div className="flex justify-between items-start mb-2">
            <div>
              <div className="text-xs text-gray-400">Net Worth</div>
              <div className="text-3xl mt-1">₹25,400</div>
              <div className="text-xs text-[#4ade80] mt-1 flex items-center gap-1">
                <TrendingUp className="size-3" />
                ₹540 today (+2.16%)
              </div>
            </div>
            <div className="w-12 h-12 bg-[#1a2332] rounded-lg flex items-center justify-center">
              <TrendingUp className="size-6 text-[#4ade80]" />
            </div>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="px-4 mb-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-500" />
          <input 
            type="text"
            placeholder="Search portfolios, bonds..."
            className="w-full bg-[#0f1420] border border-gray-800 rounded-lg pl-10 pr-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-gray-700"
          />
        </div>
      </div>

      {/* Categories */}
      <div className="px-4 mb-4">
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {categories.map((cat, idx) => (
            <button
              key={cat}
              className={`px-4 py-2 rounded-lg text-sm whitespace-nowrap ${
                idx === 0 
                  ? "bg-[#4ade80] text-black" 
                  : "bg-[#0f1420] text-gray-400 border border-gray-800"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Featured Portfolios */}
      <div className="px-4 mb-4">
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-lg">Featured Portfolios</h2>
          <button className="text-sm text-[#4ade80]">See All</button>
        </div>

        <div className="space-y-3">
          {portfolioData.map((portfolio) => (
            <Link
              key={portfolio.id}
              to={`/portfolio/${portfolio.id}`}
              className="block bg-[#0f1420] rounded-2xl p-4 border border-gray-800 hover:border-gray-700 transition-colors"
            >
              <div className="flex justify-between items-start mb-3">
                <div className="flex-1">
                  <h3 className="text-base mb-1">{portfolio.name}</h3>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-[#4ade80]">{portfolio.returns} p.a.</span>
                    <span className="text-gray-500">•</span>
                    <span className="text-gray-400">{portfolio.risk}</span>
                  </div>
                </div>
                <div className="w-16 h-10">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={sparklineData}>
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke="#4ade80" 
                        strokeWidth={2}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
              
              <div className="flex gap-4 text-xs text-gray-400 mb-3">
                <div>
                  <span className="text-gray-500">{portfolio.duration} avg. duration</span>
                </div>
                <div>
                  <span className="text-gray-500">Min. Invest {portfolio.minInvest}</span>
                </div>
              </div>

              <button className="w-full bg-[#4ade80] text-black py-3 rounded-lg text-sm hover:bg-[#3dcc70] transition-colors">
                View Details
              </button>
            </Link>
          ))}
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
