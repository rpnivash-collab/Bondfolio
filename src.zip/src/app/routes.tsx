import { createBrowserRouter } from "react-router";
import Home from "./pages/Home";
import PortfolioDetails from "./pages/PortfolioDetails";
import InvestScreen from "./pages/InvestScreen";
import PortfolioTracking from "./pages/PortfolioTracking";
import Account from "./pages/Account";
import WhyDebtMarket from "./pages/WhyDebtMarket";
import Explore from "./pages/Explore";
import Orders from "./pages/Orders";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/explore",
    Component: Explore,
  },
  {
    path: "/portfolio/:id",
    Component: PortfolioDetails,
  },
  {
    path: "/invest/:id",
    Component: InvestScreen,
  },
  {
    path: "/tracking",
    Component: PortfolioTracking,
  },
  {
    path: "/orders",
    Component: Orders,
  },
  {
    path: "/account",
    Component: Account,
  },
  {
    path: "/why-debt",
    Component: WhyDebtMarket,
  },
]);